import os
import json
import random
import sys
import time
import platform
from datetime import datetime

def check_inst():
    """Check if the system dir exists."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    system_folder_path = os.path.join(current_dir, 'System')

    if os.path.exists(system_folder_path) and os.path.isdir(system_folder_path):
        print('THE SYSTEM FOLDER EXISTS')
    else:
        print('THE SYSTEM FOLDER NOT EXISTS. INSTALLING SYSTEM')
        install_sys()

def install_system_files():
    """Simulate the installation of system files with a progress bar."""
    total_files = 100
    files_installed = 0

    # Display the progress bar
    while files_installed < total_files:
        progress = (files_installed / total_files) * 100
        sys.stdout.write(
            '\r[{0}] {1}%'.format('#' * int(progress // 2) + '-' * (50 - int(progress // 2)), int(progress)))
        sys.stdout.flush()

        # Simulate the installation process
        time.sleep(0.07)
        files_installed += 1

    # Finish the progress bar
    sys.stdout.write('\r[{0}] 100%\n'.format('#' * 50))
    sys.stdout.flush()
    print("SYSTEM DIRECTORY DOWNLOADING")

def install_sys():
    """Create the system directory."""
    system_folder = "System"
    if not os.path.exists(system_folder):
        os.makedirs(system_folder)
        print("SYSTEM DIRECTORY WAS CREATED")

    manuals_folder = os.path.join(system_folder, "manuals")
    if not os.path.exists(manuals_folder):
        os.makedirs(manuals_folder)
        print("CREATED MANUALS DIRECTORY")

    file1 = os.path.join(manuals_folder, "file1.man")
    file2 = os.path.join(manuals_folder, "file2.man")
    with open(file1, 'w') as f1, open(file2, 'w') as f2:
        f1.write("MANUAL 1 CONTENT\n")
        f2.write("MANUAL 2 CONTENT\n")

check_inst()

# Constants
MAX_DISK_SIZE_KB = 128
MAX_DISKS = 3
DISK_NAMES = ['diskC', 'diskD', 'diskE']
USER_DATA_FILE = 'user_data.json'
ROOT_PREFIX = 'SUDO '

class DiskSystem:
    def __init__(self):
        self.disks = {}

    def create_disk(self, disk_name, size_kb):
        """Create a new disk with the specified name and size."""
        if len(self.disks) >= MAX_DISKS:
            print(f"ERROR: MAXIMUM DISK LIMIT OF {MAX_DISKS} REACHED")
            return
        
        if size_kb > MAX_DISK_SIZE_KB:
            print(f"ERROR: DISK SIZE CANNOT EXCEED {MAX_DISK_SIZE_KB} KB")
            return
        
        if disk_name in self.disks:
            print(f"ERROR: DISK '{disk_name}' ALREADY EXISTS")
            return
        
        # Create dir to represent disk 
        if disk_name not in DISK_NAMES:
            print(f"ERROR: INVALID DISK NAME  '{disk_name}'. VALID NAMES ARE: {', '.join(DISK_NAMES)}")
            return
        
        # Create the disk directory 
        os.mkdir(disk_name)
        self.disks[disk_name] = size_kb
        print(f"DISK '{disk_name}' CREATED WITH SIZE {size_kb} KB")

    def list_disks(self):
        """List all created disks."""
        if not self.disks:
            print("NO DISKS AVAILABLE")
        else:
            print("AVAILABLE DISKS: ")
            for disk, size in self.disks.items():
                print(f"    - {disk} ({size} KB)")

    def run(self):
        """Run the disk system."""
        while True:
            command = input("DISK SYSTEM COMMANDS (CREATE, LIST, Q TO QUIT): ").strip().lower()
            if command == "q":
                break
            elif command == "create":
                disk_name = input("ENTER DISK NAME (diskC, diskD, diskE): ")
                try:
                    size_kb = int(input(f"ENTER SIZE IN KB (max {MAX_DISK_SIZE_KB} KB): "))
                    self.create_disk(disk_name, size_kb)
                except ValueError:
                    print("INVALID INPUT. PLEASE ENTER A VALID NUMBER")
            elif command == "list":
                self.list_disks()
            else:
                print("INVALID COMMAND")
 
def print_current_time():
    """Print the current date and time."""
    now = datetime.now()
    print(f"Year: {now.year}")
    print(f"Month: {now.month}")
    print(f"Day: {now.day}")
    print(f"Hour: {now.hour}")
    print(f"Minute: {now.minute}")
    print(f"Second: {now.second}")
    print(f"Microsecond: {now.microsecond}")

def random_number():
    """Print a random number between 1 and 100."""
    print(random.randint(1, 100))

def reverse_command(text):
    """Print the given text in reverse order."""
    print(text[::-1])

def load_user_data():
    """load user data"""
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'r') as file:
            return json.load(file)
    return {}

def save_user_data(user_data):
    """save user data"""
    with open(USER_DATA_FILE, 'w') as file:
        json.dump(user_data, file)

def register_user():
    """register a new user"""
    user_data = load_user_data()
    username = input("ENTER USERNAME: ")
    if username in user_data:
        print("USERNAME ALREADY EXISTS. PLEASE CHOOSE A DIFFERENT USERNAME")
        return
    password = input("ENTER PASSWORD: ")
    user_data[username] = password
    save_user_data(user_data)
    print("USER REGISTERED SUCCESFULLY!")

def login_user():
    """login in an existing user"""
    user_data = load_user_data()
    username = input("ENTER USERNAME: ")
    password = input("ENTER PASSWORD: ")
    if user_data.get(username) == password:
        print("LOGIN SUCCESFUL!")
        return True
    else:
        print("INVALID CREDENTIALS. PLEASE TRY AGAIN")
        return False

def clear_terminal():
    """clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    """Main program loop."""
    print("WELCOME TO THE SYSTEM!")
    while True:
        action = input("WOULD YOU LIKE (R)EGISTER, (L)OGIN, (Q)UIT ?").strip().upper()
        if action == 'R':
            register_user()
        elif action == 'L':
            if login_user():
                break
        elif action == 'Q':
            print("EXITING SYSTEM")
            return
        else:
            print("INVALID OPTION PLEASE TRY AGAIN")

    users_computer = input("ENTER YOUR PC NAME: ")
    start_system = input(f"{users_computer}, START SYSTEM? (yes/no): ").lower()
    if start_system != "yes":
        print("SYSTEM NOT STARTED")
        return

    disk_system = DiskSystem() # initialize disk system
    
    while True:
        command = input("COMMAND: ").strip().upper()
        if command == "Q":
            print("SHUTDOWN IN 2 SEC")
            time.sleep(2)
            break
        elif command.startswith(ROOT_PREFIX):
            command = command[len(ROOT_PREFIX):]
            if command == "CREDISK":
                disk_system.run()
            elif command == "REMDIREC":
                rem_direc()
            elif command == "REMFILE":
                rem_files()
            elif command == "ENDPROC":
                end_proc()
            elif command == "SYSTEMINFO":
                print_system_info(users_computer)
            else:
                print("INVALID ROOT COMMAND")
        elif command == "HELP":
            print_help()
        elif command == "TIME":
            print_current_time()
        elif command == "CALCULATOR":
            calculator()
        elif command == "RANDINT":
            random_number()
        elif command == "REVERSE":
            reverse_command(input("ENTER TEXT TO REVERSE: "))
        elif command == "CREATE":
            create_file()
        elif command == "CREDIR":
            create_directory()
        elif command == "REWDIR":
            review_directory()
        elif command == "REDIR":
            rename_dir()
        elif command == "CLEAR":
            clear_terminal()
        elif command == "GUESS":
            play_guess()
        elif command == "SHELP":
            sudo_help_manual()
        else:
            print("INVALID OPERATION: CHECK YOUR CALCULATION")

def print_help():
    """Print the available commands."""
    print("MANUAL FOR OS S1MP9OS!")
    print("COMMANDS ARE AVAILABLE: 'HELP', 'CALCULATOR', 'TIME', 'EXIT', 'RANDINT', 'REVERSE', 'CREATE', 'CREDIR', 'REWDIR', 'REDIR'")
    print("DEV GITHUB: https://github.com/Kross1de/S1MP9os")
    print("IDK WHAT I CAN WRITE BRUH")

def sudo_help_manual():
    print("MANUAL FOR COMMANDS WITH SUDO PREFIX")
    print("COMMANDS: CREDISK, SYSTEMINFO, REMFILE, REMDIREC, ENDPROC")
    print("FOR NORMALLY WRITE A COMMAND WRITE A PREFIX 'SUDO'")

def create_file():
    file_name = input("ENTER NAME OF YOUR FILE: ")
    with open(file_name, "w") as file:
        pass  # File will be created and closed automatically
    print("FILE WAS SUCCESSFULLY CREATED!")

def create_directory():
    directory = input("ENTER NAME OF YOUR DIRECTORY: ")
    os.mkdir(directory)

def review_directory():
    files = os.listdir()
    for file in files:
        print(file)

def random_number_game():
    """Play a number guessing game."""
    number_to_guess = random.randint(1, 1000)
    attempts = 0
    print("WELCOME TO NUMBER GUESSING GAME! GUESS THE NUMBER BETWEEN 1 TO 1000")

    while True:
        try:
            guess = int(input("ENTER YOUR GUESS: "))
            attempts += 1

            if guess < 1 or guess > 1000:
                print("PLEASE GUESS A NUMBER BETWEEN 1 TO 1000")
                continue

            if guess < number_to_guess:
                print("TOO LOW! TRY AGAIN")
            elif guess > number_to_guess:
                print("TOO HIGH! TRY AGAIN")
            else:
                print(f"CONGRATULATIONS! YOU'VE GUESS NUMBER {number_to_guess} IN {attempts} ATTEMPTS")
                break
        except ValueError:
            print("INVALID INPUT. PLEASE ENTER A VALID NUMBER")

def play_guess():
    """play game 'guess'"""
    while True:
        action = input("WOULD YOU LIKE TO (P)LAY NUMBER GUESS GAME OR (Q)UIT")
        if action == 'P':
            random_number_game()
        elif action == 'Q':
            print("EXITING")
            break
        else: 
            print("INVALID OPTION PLEASE TRY AGAIN")

def end_proc():
    process_id = input("ENTER PROCESS PID: ")
    os.system(f"taskkill /PID {process_id}")

def rename_dir():
    old_name = input("ENTER CURRENT DIRECTORY NAME: ")
    new_name = input("ENTER FUTURE DIRECTORY NAME: ")
    os.rename(old_name, new_name)

def rem_files():
    file_name = input("ENTER NAME OF YOUR FILE: ")
    if os.path.exists(file_name):
        os.remove(file_name)
        print("FILE WAS SUCCESSFULLY DELETED")
    else:
        print("THIS FILE DOES NOT EXIST")

def rem_direc():
    directory = input("ENTER NAME OF YOUR DIRECTORY: ")
    os.rmdir(directory)

def print_system_info(users_computer):
    """Print system information."""
    print(f"COMPUTER NAME: {users_computer}")
    print(f"MACHINE TYPE: {platform.machine()}")
    print(f"PROCESSOR TYPE: {platform.processor()}")
    print("PLATFORM TYPE: S1MP9osV1.5")
    print("OPERATION SYSTEM: S1MP9OS")
    print("OPERATION SYSTEM RELEASE: JANUARY I THINK")
    print("OPERATION SYSTEM VERSION: 1.5")

def calculator():
    """Perform a simple calculation."""
    calc1 = int(input("NUMBER 1: "))
    calc2 = int(input("NUMBER 2: "))
    calc3 = input("WHAT YOU WANT TO DO (+, -, *, /, **, %, //): ")
    if calc3 in ["+", "-", "*", "/", "**", "%", "//"]:
        result = eval(f"{calc1} {calc3} {calc2}")
        print(result)
    else:
        print("INVALID OPERATION: CHECK YOUR CALCULATION")

if __name__ == "__main__":
    main()