# SIMPAos Моя первая разработка которую я делаю на серьезе (в целом такая программа у меня первая т.к это 1 день когда я начал нормально изучать пайтон) ну что, погнали!
# SIMPAos My first serious development (because i really learning python 2 day) but, ok let's go!
from tkinter import *
import time

print("Loading S1MP9os")
print("INSTALLING PACKAGES: 1%")
time.sleep(0.2)
print("INSTALLING PACKAGES: 4%")
time.sleep(0.1)
print("INSTALLING PACKAGES: 24%")
time.sleep(0.1)
print("INSTALLING PACKAGES: 65%")
time.sleep(0.1)
print("INSTALLING PACKAGES: 96%")
time.sleep(2)
print("INSTALLING PACKAGES: 97%")
time.sleep(2)
print("INSTALLING PACKAGES: 99%")
time.sleep(2)
print("INSTALLING PACKAGES: 100%")
print("PACKAGES INSTALLED")
time.sleep(0.1)
print("INSTALL SYSTEM: 1%")
time.sleep(0.1)
print("INSTALL SYSTEM: 5%")
time.sleep(0.1)
print("INSTALL SYSTEM: 16%")
time.sleep(0.1)
print("INSTALL SYSTEM: 86%")
time.sleep(0.1)
print("INSTALL SYSTEM: 100%")
print("SYSTEM SUCCESFULLY INSTALLED!")
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
time.sleep(0.5)
print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
print("THANKS FOR USING S1MP9os")
print("SSSSSSSSSSSSSSSSSSSS"),print("PPPPPPPPPPPPPPPPPPPPP"),print("AAAAAAAAAAAAAAAAAAAAA")
print("11111111111111111111"),print("MMMMMMMMMMMMMMMMMMMMM"),print("OOOOOOOOOOOSSSSSSSSSS")
time.sleep(3)
commandslist = ['SYSTEMINFO', 'CALCULATOR', 'LOCALINT', 'HELP']
print("AVAILABLE COMMANDS: ", commandslist)

while True:
    command1 = input("COMMAND: ").strip().upper()
    if command1 == 'SYSTEMINFO':
        print("S1MP9os: VERSION 1.0")
        print("CPU: 16TB")
        print("RAM: 8GB")
        print("PROCESSOR: INTEL CORE I8 13600")
        print("VIDEOCARD: RTX 5090 SUPER")
    if command1 == 'CALCULATOR':
        calc1 =  int(input("NUMBER 1: "))
        calc2 =  int(input("NUMBER 2: "))
        calc3 =  input("WHAT YOU WANT DO: ")
        if calc3 == "+":
            print(calc1 + calc2)
        if calc3 == "-":
            print(calc1 - calc2)
        if calc3 == "*":
            print(calc1 * calc2)
        if calc3 == "/":
            print(calc1 / calc2)
        if calc3 == "%":
            print(calc1 % calc2)
        if calc3 == "**":
            print(calc1 ** calc2)
        if calc3 == "//":
            print(calc1 // calc2)

        if command1 == 'HELP':
            print("AVAILABLE COMMANDS:", ', '.join(commandslist))
