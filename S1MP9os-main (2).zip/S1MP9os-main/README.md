My first program that I'm doing seriously, S1MP9OS, is a pseudo-operating system that I made for practice, and now I'm doing it for creativity or an idea if someone wanted to do something like that.
