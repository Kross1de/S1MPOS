import os
import random
import sys
import time
import platform
from datetime import datetime

# Memory skeleton for future development
MEMORY = [0] * 1024
MEMORYC = [0] * 1024
MEMORYD = [0] * 1984
MEMORYSD = [0] * 64

def print_current_time():
    """Print the current date and time."""
    now = datetime.now()
    print(f"Year: {now.year}")
    print(f"Month: {now.month}")
    print(f"Day: {now.day}")
    print(f"Hour: {now.hour}")
    print(f"Minute: {now.minute}")
    print(f"Second: {now.second}")
    print(f"Microsecond: {now.microsecond}")

def random_number():
    """Print a random number between 1 and 100."""
    print(random.randint(1, 100))

def reverse_command(text):
    """Print the given text in reverse order."""
    print(text[::-1])

def main():
    """Main program loop."""
    users_password = input("ENTER YOUR PASSWORD: ")
    users_computer = input("ENTER YOUR PC NAME: ")

    start_system = input(f"{users_computer}, START SYSTEM? (yes/no): ").lower()
    if start_system != "yes":
        print("SYSTEM NOT STARTED")
        return

    while True:
        command = input("COMMAND: ").strip().upper()
        if command == "Q":
            print("SHUTDOWN IN 2 SEC")
            time.sleep(2)
            break
        elif command == "HELP":
            print_help()
        elif command == "SYSTEMINFO":
            print_system_info(users_computer)
        elif command == "TIME":
            print_current_time()
        elif command == "CALCULATOR":
            calculator()
        elif command == "RANDINT":
            random_number()
        elif command == "REVERSE":
            reverse_command(input("Enter text to reverse: "))
        elif command == "CREATE":
            create_file()
        elif command == "CREDIR":
            create_directory()
        elif command == "REWDIR":
            review_directory()
        elif command == "REDIR":
            rename_dir()
        elif command == "REMFILE":
            rem_files()
        elif command == "REMDIREC":
            rem_direc()
        elif command == "ENDPROC":
            end_proc()
        else:
            print("INVALID OPERATION: CHECK YOUR CALCULATION")

def print_help():
    """Print the available commands."""
    print("MANUAL FOR OS S1MP9OS!")
    print("COMMANDS ARE AVAILABLE: 'SYSTEMINFO', 'HELP', 'CALCULATOR', 'TIME', 'EXIT', 'RANDINT', 'REVERSE', 'CREATE', 'CREDIR', 'REWDIR', 'REDIR', 'REMFILE', 'REMDIREC', 'ENDPROC' ")
    print("DEV GITHUB: https://github.com/Kross1de/S1MP9os")
    print("IDK WHAT I CAN WRITE BRUH")

def create_file():
    file_name = input("ENTER NAME OF YOUR FILE: ")
    file = open(file_name, "w")
    file.close()
    print("FILE WAS SUCCESFULLY CREATED!")

def create_directory():
    directory = input("ENTER NAME OF YOUR DIRECTORY: ")
    os.mkadir(directory)

def review_directory():
    files = os.listdir()
    for file in files:
        print(file)

def end_proc():
    process_pid = input("ENTER PROCESS PID: ")
    os.system(f"taskkill /PID {process_pid}")

def rename_dir():
    old_name = input("ENTER CURRENT DIRECTORY NAME: ")
    new_name = input("ENTER FUTURE DIRECTORY NAME: ")
    os.rename(old_name, new_name)


def rem_files():
    file_name = input("ENTER NAME OF YOUR FILE: ")
    if os.path.exists(file_name):
        os.remove(file_name)
        print("FILE WAS SUCCESFULLY DELETED")
    else:
        print("THIS FILE NOT EXISTS")

def rem_direc():
    directory = input("ENTER NAME OF YOUR DIRECTORY")
    os.rmdir(directory)

def print_system_info(users_computer):
    """Print system information."""
    print(f"COMPUTER NAME: {users_computer}")
    print(f"MACHINE TYPE: {platform.machine()}")
    print(f"PROCESSOR TYPE: {platform.processor()}")
    print("PLATFORM TYPE: S1MP9osV1.2")
    print("OPERATION SYSTEM: S1MP9OS")
    print("OPERATION SYSTEM RELEASE: JANUARY I THINK")
    print("OPERATION SYSTEM VERSION: 1.2")

def calculator():
    """Perform a simple calculation."""
    calc1 = int(input("NUMBER 1: "))
    calc2 = int(input("NUMBER 2: "))
    calc3 = input("WHAT YOU WANT TO DO (+, -, *, /, **, %, //): ")
    if calc3 in ["+", "-", "*", "/", "**", "%", "//"]:
        result = eval(f"{calc1} {calc3} {calc2}")
        print(result)
    else:
        print("INVALID OPERATION: CHECK YOUR CALCULATION")

if __name__ == "__main__":
    main()