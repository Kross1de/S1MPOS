# first update simpaos version 1.01 first update simpaos version 1.01
import sys
import time

users_name = input("ENTER COMPUTER NAME: ")
users_password = input("ENTER YOUR PASSWORD: ")

print("LOADING S1MP9OS")
loading_steps = [1, 4, 24, 65, 96, 97, 99, 100]
for step in loading_steps:
    print(f"INSTALLING PACKAGES: {step}%")
    time.sleep(0.2 if step < 97 else 1.8)

print("PACKAGES INSTALLED")
time.sleep(0.3)

for step in [1, 5, 16, 86, 100]:
    print(f"INSTALL SYSTEM: {step}%")
    time.sleep(0.3)

print("SYSTEM SUCCESSFULLY INSTALLED!")
for _ in range(10):
    print("TRUE,                 1,1,1,1,1,1,1,1,1           1,1,1,1,1,1,1,1,")
    time.sleep(0.2)

print("RAM1: 35MB")
print("RAM2: 46MB")
time.sleep(0.4)
print(f"THANKS FOR USING S1MP9os, {users_name}")
print("SSSSSSSSSSSSSSSSSSSS PPPPPPPPPPPPPPPPPPPPP AAAAAAAAAAAAAAAAAAAAA")
print("11111111111111111111 MMMMMMMMMMMMMMMMMMMMM OOOOOOOOOOOSSSSSSSSSS")
time.sleep(1)

commandlist = ['SYSTEMINFO', 'HELP', 'CALCULATOR', 'CHANGELOG', 'OFFPC', 'FUTUREUPD', 'DELSYSTEM']
changelog1 = "BRUH SYSTEM WAS CREATED LOL"
changelog101 = "OPTIMAZED THIS SH SYSTEM, CREATED SOME NEW COMMANDS IN TERMINAL, OPTIMIZATED CODE"
futureupd102 = "MORE COMMANDS OR WORK FOR GRAPHIC INTERFACE"
offpc_process = ['1', '2', '6', '21', '43', '76', '88', '100'] # WIP COOL OFFPC_PROCESS
delsystem_process = ['1', '2', '6', '21', '43', '76', '88', '100'] # WIP COOL DELSYSTEM PROCESS
print("ALLOWED COMMANDS: ", commandlist)

while True:
    command1 = input("COMMAND: ").strip().upper()
    if command1 == 'HELP':
        print(commandlist)
    elif command1 == 'OFFPC':
        for offpc_process in [offpc_process]:
            print(f"OFFING PC: {offpc_process}%")
            time.sleep(0.2)
            sys.exit()
    elif command1 == 'DELSYSTEM':
        print("DELETING SYSTEM: 1%")
        time.sleep(1)
        print("DELETING SYSTEM: 2%")
        time.sleep(1.1)
        print("DELETING SYSTEM: 6%")
        time.sleep(5)
        print("DELETING SYSTEM: 21%")
        time.sleep(1)
        print("DELETING SYSTEM: 43%")
        time.sleep(4)
        print("DELETING SYSTEM: 76%")
        time.sleep(3.4)
        print("DELETING SYSTEM: 88%")
        time.sleep(0.4)
        print("DELETING SYSTEM: 100%")
        print("SYSTEM WAS SUCCESFULLY DELETED!")
        time.sleep(1)
        sys.exit()
    elif command1 == 'CHANGELOG':
        print(changelog1, changelog101)
    elif command1 == 'FUTUREUPD':
        print(futureupd102)
    elif command1 == 'SYSTEMINFO':
        print("S1MP9os: VERSION 1.1")
        print("RAM1: 35MB")
        print("RAM2: 46MB")
        print("PROCESSOR: INTEL CORE I8 13600")
        print("VIDEOCARD: RTX 5090 SUPER")
    elif command1 == 'CALCULATOR':
        calc1 = int(input("NUMBER 1: "))
        calc2 = int(input("NUMBER 2: "))
        calc3 = input("WHAT YOU WANT TO DO (+, -, *, /, **, %, //): ")
        if calc3 in ["+", "-", "*", "/", "**", "%", "//"]:
            result = eval(f"{calc1} {calc3} {calc2}")
            print(result)
        else:
            print("INVALID OPERATION: CHECK YOUR CALCULATION")
